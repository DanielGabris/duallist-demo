(function() {
  jQuery(function() {
    return $("select").DualListBox();
  });

}).call(this);
